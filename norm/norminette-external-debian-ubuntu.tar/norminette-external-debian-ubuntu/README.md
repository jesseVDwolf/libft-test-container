### Run install.sh as normal user
